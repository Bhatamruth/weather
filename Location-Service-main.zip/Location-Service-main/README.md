# Location-Service
This service has 2 uses till now

1) it will fetch the current location data eg (city ,state, lat, long) of the user based on the IP of the user
2) it will persist a location in the db based on the provided country abbrevation and the postal code of the area inside that country
