package com.weather.DataService.util;

public class Helper {
    public double kelvinToCelsius(double kelvin) {
        return kelvin - 273.15;
    }
}
